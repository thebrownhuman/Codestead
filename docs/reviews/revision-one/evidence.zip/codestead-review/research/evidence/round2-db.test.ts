import { afterAll, beforeAll, expect, it, vi } from 'vitest';
import pg from 'pg';

vi.mock('@/lib/db/client', () => ({ pool: { connect: () => database.connect() } }));
import { withdrawCohortProfileForConsent } from '../../src/lib/social/profile-service';

const database = new pg.Pool({ connectionString: process.env.REVIEW_DATABASE_URL });
const owner = 'research-owner';
const requestId = '11111111-1111-4111-8111-111111111111';

beforeAll(async () => {
  await database.query(`
    create table cohort_profile (
      user_id text primary key, alias text, bio text, is_published boolean,
      published_consent_record_id uuid, row_version integer, show_bio boolean,
      show_streak boolean, show_mastery_summary boolean, selected_achievement_ids uuid[],
      selected_project_ids uuid[], withdrawn_at timestamptz, updated_at timestamptz
    );
    create table user_achievement (user_id text, visibility text);
    create table project (user_id text, visibility text);
    create table cohort_profile_event (
      id uuid default gen_random_uuid(), user_id text, actor_user_id text,
      request_id uuid, event text, snapshot jsonb, evidence_hash text, reason text,
      resulting_version integer, occurred_at timestamptz
    );
    create table notification (
      user_id text, type text, title text, body text, action_url text, created_at timestamptz
    );
    insert into cohort_profile(user_id,alias,is_published,row_version) values ('research-owner','review',true,1);
    insert into user_achievement values ('research-owner','cohort');
    insert into project values ('research-owner','cohort');
  `);
});
afterAll(async () => { await database.end(); });

it('reproduces an old consent-withdrawal replay hiding newly republished badges and projects in real PostgreSQL', async () => {
  const first = await withdrawCohortProfileForConsent({userId:owner,consentRequestId:requestId});
  expect(first.replayed).toBe(false);
  // Simulate a subsequent accepted consent and successful profile publication.
  await database.query(`
    update cohort_profile set is_published=true,row_version=row_version+1;
    update user_achievement set visibility='cohort';
    update project set visibility='cohort';
  `);
  const replay = await withdrawCohortProfileForConsent({userId:owner,consentRequestId:requestId});
  expect(replay.replayed).toBe(true);
  expect((await database.query('select is_published from cohort_profile')).rows[0].is_published).toBe(true);
  expect((await database.query('select visibility from user_achievement')).rows[0].visibility).toBe('private');
  expect((await database.query('select visibility from project')).rows[0].visibility).toBe('private');
});
