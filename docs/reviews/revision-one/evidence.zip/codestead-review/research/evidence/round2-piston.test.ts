import { afterEach, expect, it, vi } from 'vitest';
import { PistonRunnerClient, PISTON_RUNTIMES } from '../../src/lib/runner/piston-client';
import type { RunnerRequest } from '../../src/lib/runner/client';

afterEach(() => vi.restoreAllMocks());
const cap = 65_536;
function request(): RunnerRequest {
  return { submissionId: '11111111-1111-4111-8111-111111111111', correlationId: 'round2',
    language: 'python', runtimeVersion: PISTON_RUNTIMES.python.label, mode: 'TEST',
    sourceFiles: [{path: 'main.py', content: 'print("ok")'}], entrypoint: 'main.py', limits: {},
    tests: [{id: 'first', visibility: 'HIDDEN', category: 'normal', stdin: '', expectedStdout: 'ok', comparison: 'EXACT'}] };
}
function client(transport: typeof fetch) {
  return new PistonRunnerClient('http://piston:2000', 'sha256:' + 'a'.repeat(64), transport);
}
function response(stdout = '', stderr = '', wallTime = 0) {
  return Response.json({run: {stdout, stderr, code: 0, signal: null, status: null, wall_time: wallTime}});
}
it('accepts hidden combined output exceeding the default cap with each upstream stream within its cap', async () => {
  let calls = 0;
  const transport = async () => ++calls === 1 ? response() : response('ok', 'x'.repeat(cap));
  const result = (await client(transport as typeof fetch).submit(request(), 'round2-hidden')).result!;
  expect(Buffer.byteLength('ok' + 'x'.repeat(cap))).toBe(cap + 2);
  expect(result.status).toBe('ACCEPTED');
  expect(result.tests[0]?.status).toBe('PASSED');
});
it('accepts visible output even when consuming stderr truncates the default combined budget', async () => {
  let calls = 0;
  const transport = async () => ++calls === 1 ? response() : response('ok', 'x'.repeat(cap));
  const input = request(); input.tests![0]!.visibility = 'VISIBLE';
  const result = (await client(transport as typeof fetch).submit(input, 'round2-visible')).result!;
  expect(result.status).toBe('ACCEPTED');
  expect(result.tests[0]?.stderr).toContain('<output truncated>');
});
it('accepts two tests whose combined stdout exceeds the default job-wide cap', async () => {
  let calls = 0;
  const output = 'x'.repeat(40_000);
  const transport = async () => ++calls === 1 ? response() : response(output);
  const input = request();
  input.tests = [{...input.tests![0]!, expectedStdout: output}, {...input.tests![0]!, id: 'second', expectedStdout: output}];
  const result = (await client(transport as typeof fetch).submit(input, 'round2-multi')).result!;
  expect(result.status).toBe('ACCEPTED');
  expect(result.totals.passed).toBe(2);
});
it('gives every call the complete requested wall limit rather than sharing the legacy job deadline', async () => {
  let now = 1_000; let calls = 0;
  vi.spyOn(Date, 'now').mockImplementation(() => now);
  const bodies: Record<string, unknown>[] = [];
  const transport = async (_url: unknown, init: RequestInit) => {
    bodies.push(JSON.parse(String(init.body)));
    now += 4;
    return ++calls === 1 ? response('', '', 4) : response('ok', '', 4);
  };
  const input = request(); input.limits = {wallTimeMs: 10};
  input.tests!.push({...input.tests![0]!, id: 'second'});
  const result = (await client(transport as typeof fetch).submit(input, 'round2-time')).result!;
  expect(now - 1_000).toBe(12);
  expect(result.status).toBe('ACCEPTED');
  expect(bodies.every(body => body.run_timeout === 10 && body.compile_timeout === 10_000)).toBe(true);
});
it('does enforce the separate 15-second whole-operation transport deadline', async () => {
  let now = 1_000;
  vi.spyOn(Date, 'now').mockImplementation(() => now);
  const transport = async () => { now += 15_001; return response(); };
  await expect(client(transport as typeof fetch).submit(request(), 'round2-deadline')).rejects.toMatchObject({code: 'PISTON_TIMEOUT'});
});
