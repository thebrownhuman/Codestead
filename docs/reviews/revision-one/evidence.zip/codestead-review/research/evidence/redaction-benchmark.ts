import { performance } from 'node:perf_hooks';
import { redactSensitiveText } from '../../src/lib/security/sensitive-text';

const words = Number(process.argv[2]);
const input = 'a '.repeat(words);
const started = performance.now();
const result = redactSensitiveText(input, 4_000);
console.log(JSON.stringify({ words, chars: input.length, elapsedMs: performance.now() - started, redacted: result.redacted, outputChars: result.text.length }));
