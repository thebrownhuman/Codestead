import { defineConfig } from 'vitest/config';
import path from 'node:path';
export default defineConfig({
  resolve: {alias: {'@': path.resolve(process.cwd(), 'src')}},
  test: {include: ['.local-dev/review/round2-piston.test.ts'], environment: 'node', maxWorkers: 1,
    reporters: ['default', 'json'], outputFile: {json: '/workspace/codestead-review/research/piston-probe-results.json'}},
});
