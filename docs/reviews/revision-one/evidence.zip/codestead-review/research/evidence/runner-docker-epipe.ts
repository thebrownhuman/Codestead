import { NodeProcessExecutor } from '../../services/runner/src/process-executor';

// The image is deliberately absent and pulls are disabled: no job/container is created.
void new NodeProcessExecutor().run({
  command: 'docker',
  args: ['run','--rm','--pull=never','--interactive','--network','none','codestead-review-absent-image:round2'],
  stdin: 'x'.repeat(131_072),
  timeoutMs: 3_000,
  maxOutputBytes: 4_096,
}).then(result=>console.log(JSON.stringify(result)),error=>console.log(JSON.stringify({rejected:true,name:error.name})));
