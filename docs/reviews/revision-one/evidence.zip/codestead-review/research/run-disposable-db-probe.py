import os, pathlib, socket, subprocess, time, uuid

name='codestead-research-'+uuid.uuid4().hex[:12]
image='postgres:17-alpine@sha256:b0f9560a2de083e2cc7382e75f808c7381a32852a7ec49117deedb300e552b24'
log=pathlib.Path('/workspace/codestead-review/research/db-probe.log')
with socket.socket() as reservation:
 reservation.bind(('127.0.0.1',0)); port=reservation.getsockname()[1]
created=False
try:
 result=subprocess.run(['docker','run','--rm','-d','--name',name,'--label','codestead.review=round2',
   '--publish',f'127.0.0.1:{port}:5432','--tmpfs','/var/lib/postgresql/data:rw,size=512m',
   '-e','POSTGRES_HOST_AUTH_METHOD=trust',image],capture_output=True,text=True,timeout=20)
 if result.returncode:raise RuntimeError(result.stderr[:500])
 created=True
 for attempt in range(60):
  probe=subprocess.run(['docker','exec',name,'pg_isready','-U','postgres'],capture_output=True,timeout=3)
  if probe.returncode==0:break
  time.sleep(.2)
 else:raise RuntimeError('Disposable PostgreSQL failed readiness')
 env=os.environ.copy();env['REVIEW_DATABASE_URL']=f'postgresql://postgres@127.0.0.1:{port}/postgres'
 result=subprocess.run(['./node_modules/.bin/vitest','run','--config','.local-dev/review/round2-node.config.ts'],
    cwd='/workspace/Codestead',env=env,capture_output=True,text=True,timeout=60)
 log.write_text(result.stdout+'\n'+result.stderr)
 print('Real PostgreSQL probe exit:',result.returncode,flush=True)
 print(result.stdout[-2200:],flush=True)
 if result.returncode:
  print(result.stderr[-1500:],flush=True)
  raise SystemExit(result.returncode)
finally:
 if created:
  cleanup=subprocess.run(['docker','rm','-f',name],capture_output=True,text=True,timeout=15)
  print('Owned container cleanup exit:',cleanup.returncode,flush=True)
