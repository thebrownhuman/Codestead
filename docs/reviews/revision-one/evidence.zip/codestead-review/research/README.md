# Research evidence and reproduction

Repository: `/workspace/Codestead`, commit `7a0dda402f0a3486c85de75f2c5fe5bbd8654479`. Host: Node 24.19.0. Research date: 2026-10-06. No tracked application source or lockfile changes.

Start with [RESEARCH_ADDENDUM.md](/workspace/codestead-review/RESEARCH_ADDENDUM.md) and [NEW_LIBRARIES.md](/workspace/codestead-review/NEW_LIBRARIES.md). `SOURCE_CATALOG.md` and `upstream/source-index.json` identify successful/failed upstream requests and retained body hashes. Existing onboarding/full-suite results are reused at the same commit rather than presented as freshly rerun.

## Repository probes

Copies of ignored probe files are under `research/evidence/`. Relative imports assume the original location `/workspace/Codestead/.local-dev/review/`. Copy them there when reproducing on another checkout and adjust absolute evidence-output paths in configs.

```bash
cd /workspace/Codestead
./node_modules/.bin/vitest run --config .local-dev/review/vitest.config.ts
./node_modules/.bin/vitest run --config .local-dev/review/round2-piston.config.ts
python /workspace/codestead-review/research/run-disposable-db-probe.py
```

The first suite has nine original defect assertions. The second has four new Piston counterexamples and one negative control confirming the whole-operation transport deadline. Piston/GitHub transports are mocked. The PostgreSQL test executes the real withdrawal helper against a minimal five-table fixture, simulates later publication with SQL, and tests an old replay. It does not run complete production migrations/roles or a full authenticated route.

The PostgreSQL harness starts only its own uniquely named/labeled container, binds a loopback port, uses temporary tmpfs data and removes that owned container in `finally`. Its image is digest-pinned. It uses trust auth solely on this disposable local test DB. Docker and the cached pinned image are required; no production database is used.

```bash
node --import tsx .local-dev/review/runner-epipe.ts
node --import tsx .local-dev/review/runner-docker-epipe.ts
node --import tsx .local-dev/review/redaction-benchmark.ts 32768
```

Run subprocess crash/large-input probes only in disposable child processes with an external deadline. The first runner probe is expected to crash its own Node helper process; the actual missing-image Docker probe returned a normal error. Neither is a demonstrated live learner-to-container exploit. Redaction timings are host/runtime-specific; `32768` repeated words produce 65,536 characters. The stored larger-case deadline was eight seconds. Do not run synthetic load inside a production service.

## Isolated library lab

The lab is outside the application. Its `package.json` and `package-lock.json` pin the tested candidate versions. Install scripts are disabled. Archives omit `node_modules` and npm cache; install before reproducing.

```bash
cd /workspace/codestead-review/research/library-lab
npm ci --ignore-scripts --no-fund --no-audit --cache /workspace/codestead-review/research/npm-cache
node probes.mjs
./node_modules/.bin/depcruise fixtures --config .dependency-cruiser.cjs --output-type err-long
npm audit --package-lock-only --json --cache /workspace/codestead-review/research/npm-cache
```

`probes.mjs` uses fake-indexeddb from the application install, so the root dependencies must already be installed. Seven assertions cover Execa early closure and combined-buffer behavior, IDB commit semantics, DST/calendar behavior, RE2 incompatibility and p-limit queuing. The dependency fixture intentionally violates a rule; `err-long` must exit one. For JSON output inspect `summary.error`, `summary.advisedExitCode` and `summary.totalCruised` explicitly.

The extra alias `source-map-js-fixed` resolves to exact `source-map-js@1.2.2` without changing the app's package. `source-map-offset-probe.cjs` accepts a module path and offset argument. The stored comparison uses installed `1.2.1` and lab `1.2.2`; all runs have a disposable child-process deadline and 128 MiB heap limit. The old implementation failed at its heap limit, while the patched constructor rejected the offset. No application endpoint exploit is established. Balanced single-literal braces cases were unsuccessful reproductions; those results are retained rather than described as confirmed crashes.

## Audits and primary sources

`audit-recheck.json` and `audit-production-recheck.json` are the later root-lock registry snapshots. Their nonzero vulnerability result is expected. `library-lab-audit.json` pertains only to the isolated candidate lock. Upstream bodies include documentation, source, tests and published GitHub advisory records. Reading upstream tests is not running their suites. Moving upstream branch URLs are tied to retrieval timestamps and SHA-256 hashes; Piston contract research additionally uses the repository's exact pinned commit.

The source-fetch script covers the initial batch; subsequent supplemental requests and failed paths are recorded in the complete source index. The index is authoritative for the full set. Some direct API/documentation domains were blocked; accessible official GitHub sources supplied the relevant contracts/advisories. There were no live AI/Gmail calls, real R2 restores, full authenticated browser journeys or actual language-image executions in this follow-up.
