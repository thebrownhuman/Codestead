import concurrent.futures, datetime, hashlib, json, pathlib, urllib.request

root = pathlib.Path('/workspace/codestead-review/research/upstream')
root.mkdir(parents=True, exist_ok=True)
sources = [
 ('execa-termination', 'https://raw.githubusercontent.com/sindresorhus/execa/main/docs/termination.md'),
 ('execa-buffering', 'https://raw.githubusercontent.com/sindresorhus/execa/main/docs/buffering.md'),
 ('execa-package', 'https://raw.githubusercontent.com/sindresorhus/execa/main/package.json'),
 ('idb-readme', 'https://raw.githubusercontent.com/jakearchibald/idb/master/README.md'),
 ('radix-dialog', 'https://raw.githubusercontent.com/radix-ui/primitives/main/packages/react/dialog/src/dialog.tsx'),
 ('radix-focus-scope', 'https://raw.githubusercontent.com/radix-ui/primitives/main/packages/react/focus-scope/src/focus-scope.tsx'),
 ('floating-dismiss', 'https://raw.githubusercontent.com/floating-ui/floating-ui/master/packages/react/src/hooks/useDismiss.ts'),
 ('floating-focus', 'https://raw.githubusercontent.com/floating-ui/floating-ui/master/packages/react/src/components/FloatingFocusManager.tsx'),
 ('internationalized-date', 'https://raw.githubusercontent.com/adobe/react-spectrum/main/packages/@internationalized/date/README.md'),
 ('zod-json-schema', 'https://zod.dev/json-schema'),
 ('depcruise-readme', 'https://raw.githubusercontent.com/sverweij/dependency-cruiser/main/README.md'),
 ('depcruise-rules', 'https://raw.githubusercontent.com/sverweij/dependency-cruiser/main/doc/rules-reference.md'),
 ('piston-api', 'https://raw.githubusercontent.com/engineer-man/piston/master/readme.md'),
 ('piston-execute', 'https://raw.githubusercontent.com/engineer-man/piston/master/api/src/job.js'),
 ('octokit-readme', 'https://raw.githubusercontent.com/octokit/rest.js/main/README.md'),
 ('openai-readme', 'https://raw.githubusercontent.com/openai/openai-node/master/README.md'),
 ('anthropic-readme', 'https://raw.githubusercontent.com/anthropics/anthropic-sdk-typescript/main/README.md'),
 ('ipaddr-readme', 'https://raw.githubusercontent.com/whitequark/ipaddr.js/master/README.md'),
 ('pgboss-readme', 'https://raw.githubusercontent.com/timgit/pg-boss/master/README.md'),
 ('graphile-worker-readme', 'https://raw.githubusercontent.com/graphile/worker/main/README.md'),
 ('restic-consistency', 'https://restic.readthedocs.io/en/stable/040_backup.html'),
 ('node-streams', 'https://nodejs.org/api/stream.html'),
 ('re2-readme', 'https://raw.githubusercontent.com/uhop/node-re2/master/README.md'),
 ('openapi-zod-readme', 'https://raw.githubusercontent.com/asteasolutions/zod-to-openapi/master/README.md'),
 ('otel-pg-readme', 'https://raw.githubusercontent.com/open-telemetry/opentelemetry-js-contrib/main/packages/instrumentation-pg/README.md'),
 ('temporal-readme', 'https://raw.githubusercontent.com/js-temporal/temporal-polyfill/main/README.md'),
 ('p-limit-readme', 'https://raw.githubusercontent.com/sindresorhus/p-limit/main/readme.md'),
 ('p-cancelable-readme', 'https://raw.githubusercontent.com/sindresorhus/p-cancelable/main/readme.md'),
]

def fetch(item):
 name, url = item
 try:
  request = urllib.request.Request(url, headers={'User-Agent': 'Codestead-Code-Review/1.0'})
  with urllib.request.urlopen(request, timeout=20) as response:
   body = response.read(1_000_001)
   if len(body)>1_000_000:raise ValueError('source exceeded 1MB evidence cap')
   record = {'name':name, 'url':url, 'finalUrl':response.url, 'httpStatus':response.status,
             'bytes':len(body), 'sha256':hashlib.sha256(body).hexdigest(),
             'fetchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
   (root/(name+'.txt')).write_bytes(body)
   return record
 except Exception as error:
  return {'name':name, 'url':url, 'error':str(error)[:300]}

with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
 records=list(executor.map(fetch,sources))
(root/'source-index.json').write_text(json.dumps(records,indent=2)+'\n')
for record in records:
 print(json.dumps({key:record[key] for key in ['name','httpStatus','bytes','error'] if key in record}),flush=True)
