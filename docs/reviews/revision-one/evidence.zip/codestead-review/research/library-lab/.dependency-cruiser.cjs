module.exports = {
  forbidden: [{name:'domain-no-db',severity:'error',from:{path:'fixtures/domain/'},to:{path:'fixtures/db/'}}],
  options: {tsPreCompilationDeps:true},
};
