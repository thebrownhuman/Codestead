import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {performance} from 'node:perf_hooks';
import {execa} from 'execa';
import pLimit from 'p-limit';
import {parseZonedDateTime} from '@internationalized/date';
import {RE2} from 're2-wasm';
import '/workspace/Codestead/node_modules/fake-indexeddb/auto/index.mjs';
import {openDB,deleteDB} from 'idb';

const results=[];
async function probe(name,run){
 const start=performance.now();
 try{const detail=await run();results.push({name,passed:true,elapsedMs:performance.now()-start,detail});}
 catch(error){results.push({name,passed:false,message:error.message});}
}

await probe('Execa contains early-closed stdin rather than crashing the host',async()=>{
 const result=await execa('/usr/bin/true',[],{input:'x'.repeat(131072),timeout:1000,maxBuffer:1024,encoding:'buffer',reject:false});
 assert.equal(result.exitCode,0); assert.equal(result.failed,false);
 return {exitCode:result.exitCode,failed:result.failed,code:result.code};
});
await probe('Execa maxBuffer does not implement the runner combined-stream byte cap',async()=>{
 const result=await execa(process.execPath,['-e','process.stdout.write("x".repeat(700));process.stderr.write("y".repeat(700));'],
  {maxBuffer:1024,encoding:'buffer',all:true});
 const combined=result.stdout.length+result.stderr.length;
 assert(combined>1024);return {combinedBytes:combined,accepted:true};
});
await probe('idb request success is distinct from transaction commit',async()=>{
 const name='codestead-library-review';
 const db=await openDB(name,1,{upgrade(db){db.createObjectStore('records');}});
 const tx=db.transaction('records','readwrite');
 await tx.store.put('synthetic-review','key');
 tx.abort();
 await assert.rejects(tx.done);
 assert.equal(await db.get('records','key'),undefined);
 db.close();await deleteDB(name);
 return {requestSucceeded:true,commitRejected:true,persisted:false};
});
await probe('Calendar days preserve local clock time across DST',async()=>{
 const first=parseZonedDateTime('2026-03-08T01:30[America/New_York]');
 const next=first.add({days:1});
 const elapsed=(next.toDate().getTime()-first.toDate().getTime())/3600000;
 assert.equal(next.hour,1);assert.equal(elapsed,23);
 return {localDayLater:next.toString(),elapsedHours:elapsed};
});
await probe('DST-gap conversion can reject ambiguous local input explicitly',async()=>{
 assert.throws(()=>parseZonedDateTime('2026-03-08T02:30[America/New_York]','reject'));
 return {nonexistentLocalTimeRejected:true};
});
await probe('RE2 cannot compile the existing detector lookbehind unchanged',async()=>{
 assert.throws(()=>new RE2('(?<![A-Za-z0-9_])secret','u'));
 return {notDropIn:true};
});
await probe('p-limit bounds active work but queued tasks remain an application concern',async()=>{
 const limit=pLimit(2);let active=0,peak=0;
 const jobs=Array.from({length:8},()=>limit(async()=>{peak=Math.max(peak,++active);await new Promise(r=>setTimeout(r,10));active--;return true;}));
 const queued=limit.pendingCount;await Promise.all(jobs);
 assert.equal(peak,2);return {peakActive:peak,queuedImmediately:queued};
});
await writeFile('../library-probe-results.json',JSON.stringify(results,null,2)+'\n');
for(const result of results)console.log(JSON.stringify(result));
if(results.some(x=>!x.passed))process.exitCode=1;
