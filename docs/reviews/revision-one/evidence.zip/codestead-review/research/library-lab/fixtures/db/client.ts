export const database = 'synthetic-review';
