import { database } from '../db/client';
export const example = database;
