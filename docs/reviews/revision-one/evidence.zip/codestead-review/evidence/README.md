# Review evidence and reproduction

Repository commit: `7a0dda402f0a3486c85de75f2c5fe5bbd8654479`. Review date: 2026-10-06. Host Node: 24.19.0. No application source or lockfile edits were made.

## Targeted probes

The original ignored files are at `/workspace/Codestead/.local-dev/review/`. Copies are included in this evidence directory. Their relative imports assume they live in the original location; on another checkout, copy them to `.local-dev/review/` before running them.

From `/workspace/Codestead`:

```bash
npx vitest run --config .local-dev/review/vitest.config.ts
node --import tsx .local-dev/review/runner-epipe.ts
```

The Vitest suite contains **nine defect reproductions**. Assertions expect the current bad behavior, so a passing probe confirms a finding, rather than application correctness. They use mocked Piston/GitHub responses and synthetic privacy sentinels; they do not make provider calls. The architecture probe extracts and executes the actual checked-in rule functions. The pending-promise checks observe non-settlement over a short interval and are corroborated by the missing source cleanup.

The runner probe deliberately invokes `/usr/bin/true` with 65,536 stdin bytes inside its own disposable Node process. Expected result at the reviewed commit: exit 1 with `Unhandled 'error' event` / `write EPIPE` at `process-executor.ts:114`. Do not run it inside the production runner process. This proves the process helper crash, not a complete live-container exploit.

The stored config writes its JSON results to `/workspace/codestead-review/probe-results.json`; change that output path when reproducing elsewhere. The copied code is evidence, not a proposed regression-test patch.

## Fresh review checks

```bash
npm run test:auth-boundary
npm run content:validate
npm run architecture:check
npm run security:dependencies:known
npm audit --package-lock-only --json
npm audit --package-lock-only --omit=dev --json
npm ls braces source-map-js --all
```

The two audit commands exit nonzero at the reviewed lock. Their original JSON is retained as `audit-full.json` and `audit-production.json`. Audit advisories are time-sensitive; a later registry result can differ. The historical-advisory gate passing does not contradict a general live audit failing.

## Other validation reused

The report reuses the full unit/build/integration/runner results from onboarding at the same unchanged commit. It does not claim all those commands were rerun during this review. See the report's verification table for exact counts and limits.

## What this evidence does not establish

No production incidents or compromises were investigated. No real R2 restore, authenticated full browser suite, production host configuration, actual language-runtime image execution, external AI/Gmail delivery, or full production load test was performed. Static findings about CI, backup scope/consistency and total GitHub workload are identified as source-confirmed rather than end-to-end exploit reproductions.
