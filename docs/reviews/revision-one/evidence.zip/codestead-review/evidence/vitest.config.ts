import { defineConfig } from 'vitest/config';
import path from 'node:path';
export default defineConfig({
  resolve: { alias: { '@': path.resolve(process.cwd(), 'src') } },
  test: { include: ['.local-dev/review/probes.test.tsx'], environment: 'jsdom', maxWorkers: 1, reporters: ['default', 'json'], outputFile: { json: '/workspace/codestead-review/probe-results.json' } },
});
