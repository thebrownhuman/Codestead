import { NodeProcessExecutor } from '../../services/runner/src/process-executor.ts';

// Run in a disposable child process: the reviewed implementation crashes Node.
void new NodeProcessExecutor().run({
  command: '/usr/bin/true',
  args: [],
  stdin: 'x'.repeat(65_536),
  timeoutMs: 1_000,
  maxOutputBytes: 1_024,
});
