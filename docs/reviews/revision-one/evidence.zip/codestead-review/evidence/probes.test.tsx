import React from 'react';
import { afterEach, expect, it } from 'vitest';
import { act, cleanup, render, renderHook } from '@testing-library/react';
import { PistonRunnerClient } from '../../src/lib/runner/piston-client';
import type { RunnerRequest } from '../../src/lib/runner/client';
import { rewriteEnvelope, envelopeTarget } from '../../src/lib/observability/envelope-tunnel';
import { scrubEvent } from '../../src/lib/observability/error-monitoring';
import { ModalDialog } from '../../src/components/ui/modal-dialog';
import { useConfirm } from '../../src/components/ui/use-confirm';
import { registerStepUpPrompter, withStepUp } from '../../src/components/admin/step-up-request';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
import { reviewPublicRepository } from '../../src/lib/github/reviewer';

afterEach(cleanup);
const pause = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
function req(): RunnerRequest {
 return {submissionId:'11111111-1111-4111-8111-111111111111', correlationId:'test-correlation',language:'python',runtimeVersion:'Python 3.14',mode:'TEST',sourceFiles:[{path:'main.py',content:'print("bad")'}],entrypoint:'main.py',limits:{outputBytes:16},tests:[{id:'test-1',visibility:'HIDDEN',category:'normal',stdin:'',expectedStdout:'',comparison:'EXACT'}]};
}
function client(output: string, stderr='') {
 let count=0;
 const transport=async () => Response.json({run:{stdout:++count===1?'':output,stderr:count===1?'':stderr,code:0,signal:null,status:null}});
 return new PistonRunnerClient('http://piston:2000','sha256:'+'a'.repeat(64),transport as typeof fetch);
}
it('reproduces Piston accepting nonempty output when truncation erases it',async()=>{
 const job=await client('WRONG OUTPUT THAT EXCEEDS SIXTEEN BYTES').submit(req(),'review-test');
 expect(job.result?.status).toBe('ACCEPTED');
 expect(job.result?.tests[0]?.status).toBe('PASSED');
});
it('reproduces Piston ignoring hidden-test stderr against its requested output budget',async()=>{
 const r=req();r.tests![0]!.expectedStdout='ok';
 const job=await client('ok','x'.repeat(100)).submit(r,'review-test');
 expect(job.result?.status).toBe('ACCEPTED');
});
it('reproduces unsanitized error-envelope forwarding',()=>{
 const target=envelopeTarget('https://public@example.com/1')!;
 const body=JSON.stringify({event_id:'review'})+'\n'+JSON.stringify({type:'event'})+'\n'+JSON.stringify({user:{email:'review@example.invalid'},request:{headers:{authorization:'Bearer SYNTHETIC_REVIEW_SENTINEL'}}});
 const forwarded=rewriteEnvelope(body,target)!;
 expect(forwarded).toContain('SYNTHETIC_REVIEW_SENTINEL');
 expect(forwarded).toContain('review@example.invalid');
});
it('reproduces scrubEvent preserving unsanitized fingerprint strings',()=>{
 expect(scrubEvent({fingerprint:['Bearer SYNTHETIC_REVIEW_SENTINEL']})).toEqual({fingerprint:['Bearer SYNTHETIC_REVIEW_SENTINEL']});
});
it('reproduces focus escaping a modal through content outside its immediate parent',()=>{
 const r=render(<div><button data-testid='outside'>outside</button><div><ModalDialog backdropClassName='' dialogClassName='' labelledBy='title' onClose={()=>{}}><h2 id='title'>Review</h2><button>inside</button></ModalDialog></div></div>);
 const outside=r.getByTestId('outside');outside.focus();
 expect(document.activeElement).toBe(outside);
 expect(outside.closest('[inert]')).toBeNull();
});
it('reproduces confirmation remaining unresolved after its host unmounts',async()=>{
 const r=renderHook(useConfirm);let pending:Promise<boolean>;
 act(()=>{pending=r.result.current.confirm({title:'Review'});});r.unmount();
 expect(await Promise.race([pending!.then(()=> 'resolved'),pause(30).then(()=> 'unresolved')])).toBe('unresolved');
});
it('reproduces global step-up leaving later requests waiting after prompter unmount',async()=>{
 registerStepUpPrompter(()=>new Promise<boolean>(()=>{}));
 const denied=()=>Promise.resolve(Response.json({code:'FRESH_MFA_REQUIRED'},{status:403}));
 const first=withStepUp(denied);await pause(10);registerStepUpPrompter(null);
 registerStepUpPrompter(()=>Promise.resolve(true));
 const second=withStepUp(denied);
 expect(await Promise.race([second.then(()=> 'resolved'),pause(30).then(()=> 'unresolved')])).toBe('unresolved');
void first;registerStepUpPrompter(null);
});
it('reproduces architecture rules accepting a forbidden relative import and a comment before use client',()=>{
 const source=readFileSync('scripts/verify-import-boundaries.ts','utf8');
 const ast=ts.createSourceFile('gate.ts',source,ts.ScriptTarget.Latest,true);
 const functions=ast.statements.filter(statement=>ts.isFunctionDeclaration(statement)&&['isNodeImport','boundaryRule'].includes(statement.name?.text??'')).map(statement=>statement.getText(ast)).join('\n');
 const js=ts.transpileModule(functions,{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
 const rule=new Function(js+'\nreturn boundaryRule;')() as (file:string,specifier:string,source:string)=>string|null;
 expect(rule('src/lib/domain/example.ts','@/lib/db/client','')).toBeTruthy();
 expect(rule('src/lib/domain/example.ts','../db/client','')).toBeNull();
 expect(rule('src/lib/example.ts','node:fs','"use client";')).toBeTruthy();
 expect(rule('src/lib/example.ts','node:fs','// valid leading comment\n"use client";')).toBeNull();
});
it('reproduces project-review deductions for README and tests present beyond the selected 120 files',async()=>{
 const sha='a'.repeat(40);
 const tree=Array.from({length:120},(_,i)=>({path:`000/${i.toString().padStart(3,'0')}.ts`,type:'blob',sha,size:1}));
 tree.push({path:'README.md',type:'blob',sha,size:1},{path:'tests/example.test.ts',type:'blob',sha,size:1});
 const transport=async(url:string|URL|Request)=>{
  const u=String(url);
  if(u.includes('/commits/')) return Response.json({sha,commit:{tree:{sha}}});
  if(u.includes('/git/trees/')) return Response.json({truncated:false,tree});
  if(u.includes('/git/blobs/')) return Response.json({content:'eA==',encoding:'base64',size:1});
  return Response.json({private:false,default_branch:'main'});
 };
 const result=await reviewPublicRepository('https://github.com/example/review',transport as typeof fetch);
 expect(result.findings.some(f=>f.ruleId==='documentation.missing-readme')).toBe(true);
 expect(result.findings.some(f=>f.ruleId==='testing.missing-tests')).toBe(true);
 expect(result.qualityAssessment!.score).toBeLessThan(100);
});
